'use strict';

const express = require("express");
const dotenv = require('dotenv');
const connectDB = require('./models/db');

const matchRouter = require("./routers/matches");
const courtRoutes = require('./routers/courts');

const errorHandler = require('./middleware/errorHandler');
const notFound = require('./middleware/notFound');


dotenv.config();
connectDB();

const app = express();

app.use(express.json());

app.use("/api/matches", matchRouter);
app.use("/api/courts", courtRoutes);

app.use(notFound);          
app.use(errorHandler); 

const PORT = process.env.PORT || 4000;
app.listen(PORT, (err) => {
  if (err) {
    console.error(err);
    return;
  }
  console.log(`Server listening on port ${PORT}`);
});
